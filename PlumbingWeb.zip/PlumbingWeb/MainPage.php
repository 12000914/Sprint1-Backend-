<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<!.........................................JQUERY CDN FOR ICON...................................................>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!--Get your own code at fontawesome.com(icons)-->   
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

</head>
<style>
*{
box-sizing:border-box;
}
body {
  margin: 0;
}
.heading{
font-family:'Barlow Condensed';
font-size:40px;font-weight:bold;
color:black;
text-align:center;
margin-top:6%;
margin-bottom:6%;
}
.heading_col{
font-family:'Barlow Condensed';
font-size:40px;font-weight:bold;
color:black;
text-align:center;
margin-top:6%;
margin-bottom:1%;
}
.heading_col1{
font-family:'Barlow Condensed';
font-size:33px;font-weight:bold;
color:black;
text-align:center;
margin-top:6%;
padding:2px;
}
.paragraph{
font-family:'Barlow Condensed';
font-size:30px;font-weight:bold;
color:black;
text-align:center;
}
/*......................................Header...............................*/
.header {
  overflow: hidden;
  background-color:#00b20e;
  padding: 20px 10px;
}

.header-right {
float: right;

}
.active {
border:2px solid white;
border-radius:20px;
padding:6px 25px;
text-decoration:none;
color:white;

}
.header-left{
  float:left;
}
@media screen and (max-width: 500px) {

  .header-right {
    float:right;
  }
 .header-left {
    float:left;
  }

}


/*...................................................Signup Form Modal..................................................*/
/*.................................................Modal..................................................*/
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
padding-top:50px; /* Location of the box */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color:none;

        }

/* Modal Content */
.modal-content {
margin: auto;
border: 1px solid black;
background-color:white;
border-radius:10px;
width:45%;
padding:8px;
}
@media screen and (max-width:600px) {
.modal-content {
width:100%;
border-radius:1px;
border:1px solid white;
  }
}

/* The Close Button */
.close {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
}

.close:hover,
.close:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}
/*.......................................................Form...............................................*/
.submit_btn{
background-color: #00b20e;
padding:10px;
width:40%;
margin-left:auto;
margin-right:auto;
color:white;
border:1px solid #00b20e;
border-radius:5px;
}
/*.........................................................Column Shading..............................................*/
.shading_col{
}
/*..............................................Form Login/Signup.........................*/
.Register_form{
margin-top:2%;
}
input,
input[type="radio"] + label,
input[type="checkbox"] + label:before,
select option,
select {
  width: 100%;
  padding: 1em;
  line-height: 1.4;
  background-color: #f9f9f9;
  border: 1px solid #e5e5e5;
  border-radius: 3px;
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
input:focus {
  outline: 0;
  border-color: #64ac15;
}
input:focus + .input-icon i {
  color: #7ed321;
}
input:focus + .input-icon:after {
  border-right-color: #7ed321;
}
input[type="radio"] {
  display: none;
}
input[type="radio"] + label,
select {
  display: inline-block;
  width: 50%;
  text-align: center;
  float: left;
  border-radius: 0;
}
input[type="radio"] + label:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
input[type="radio"] + label:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
input[type="radio"] + label i {
  padding-right: 0.4em;
}
input[type="radio"]:checked + label,
input:checked + label:before,
select:focus,
select:active {
  background-color: #7ed321;
  color: #fff;
  border-color: #64ac15;
}
input[type="checkbox"] {
  display: none;
}
input[type="checkbox"] + label {
  position: relative;
  display: block;
  padding-left: 1.6em;
}
input[type="checkbox"] + label:before {
  position: absolute;
  top: 0.2em;
  left: 0;
  display: block;
  width: 1em;
  height: 1em;
  padding: 0;
  content: "";
}
input[type="checkbox"] + label:after {
  position: absolute;
  top: 0.45em;
  left: 0.2em;
  font-size: 0.8em;
  color: #fff;
  opacity: 0;
  font-family: FontAwesome;
  content: "\f00c";
}
input:checked + label:after {
  opacity: 1;
}
select {
  height: 3.4em;
  line-height: 2;
}
select:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
select:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
select:focus,
select:active {
  outline: 0;
}
select option {
  background-color:#7ed321;
  color: #fff;
}
.input-group {
  margin-bottom: 1em;
  zoom: 1;
}
.input-group:before,
.input-group:after {
  content: "";
  display: table;
}
.input-group:after {
  clear: both;
}
.input-group-icon {
  position: relative;
}
.input-group-icon input {
  padding-left: 4.4em;
}
.input-group-icon .input-icon {
  position: absolute;
  top: 0;
  left: 0;
  width: 3.4em;
  height: 3.4em;
  line-height: 3.4em;
  text-align: center;
  pointer-events: none;
}
.input-group-icon .input-icon:after {
  position: absolute;
  top: 0.6em;
  bottom: 0.6em;
  left: 3.4em;
  display: block;
  border-right: 1px solid #e5e5e5;
  content: "";
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.input-group-icon .input-icon i {
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.container {
  width:70%;
  padding: 1em 3em 2em 3em;
  margin: 0em auto;
  background-color: #fff;
  border-radius: 4.2px;
  box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.2);
}
@media screen and (max-width:600px) {
.container {
  width:100%;
}
}

.row {
  zoom: 1;
}
.row:before,
.row:after {
  content: "";
  display: table;
}
.row:after {
  clear: both;
}
/*...........................................................Modal Extra Classes tyle..................................*/
.or{
background-color:#fff;
width:30px;
margin:19px auto 10px;
font-family:"ABeeZee";
    }
.SignupLink{
text-align:center;
display:block;
text-decoration:none;
color:dimgrey;
}
.SignupLink:hover{
text-decoration:underline;
color:dimgrey;
cursor:pointer;
}
.SignIn_head{
text-align:center;
display:block;
}
/*................................................Slider...........................................................*/

.mySlides{display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
max-width:100%;
position: relative;
margin: auto;
height:550px;
}

/* The dots/bullets/indicators */
.doted{
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.activated {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

/*...............................................Circfles..............................*/
    
/*..............................................OUTLine........................................................*/
.outline{
background-color:white;
height:auto;
}
.row_Outline {
display: -ms-flexbox; /* IE10 */
display: flex;
-ms-flex-wrap: wrap; /* IE10 */
flex-wrap: wrap;
padding: 0 4px;
}

/* Create four equal columns that sits next to each other */
.col_Outline {
-ms-flex: 25%; /* IE10 */
flex: 25%;
max-width: 25%;
padding: 0 4px;
margin-top:10px;
}
.OutlineParagraph{
text-align:center;
padding:30px;
color:white;
font-size:20px; 
font-weight:700;
margin-top:-30px;
    }

.Content-Box{
margin-top:3%;
margin-left:auto;
margin-right:auto;
width:85%;
height:auto;
border:1px solid whitesmoke;
} 


@media screen and (max-width:600px) {
.btn{
width:100%;
}
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
  .col_Outline{
    -ms-flex: 50%;
    flex: 50%;
    max-width: 50%;
}
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col_Outline {
    -ms-flex: 100%;
    flex: 100%;
    max-width: 100%;
}
}

/*.........................................................Circles.....................................................*/
/* For desktop: */
.col-1 {width: 8.33%;}
.col-2 {width: 16.66%;}
.col-3 {width: 25%;}
.col-4 {width: 33.33%;}
.col-5 {width: 41.66%;}
.col-6 {width: 50%;}
.col-7 {width: 58.33%;}
.col-8 {width: 66.66%;}
.col-9 {width: 75%;}
.col-10 {width: 83.33%;}
.col-11 {width: 91.66%;}
.col-12 {width: 100%;}

.divOuter{
width:210px;
border:1px solid #00b20e;
height:210px;
border-radius:50%;
margin-left:auto;
margin-right:auto;
padding:9px 9px;
}
.divInner{
 width:190px;
border:1px solid #00b20e;
height:190px;
border-radius:50%;
margin-left:auto;
margin-right:auto;  
background-color:#00b20e;
}
.divOuter{
width:210px;
border:1px solid #A3CE38;
height:210px;
border-radius:50%;
margin-left:auto;
margin-right:auto;
padding:9px 9px;
transition:.5s;
    }
.divOuter:hover{
transform:translate(0,-10px);
cursor:pointer;
}
/*..............................................Number Grid...................................................*/

.number{
font-size:40px;
margin:20px 0;
    }
.counting_icon{
font-size:70px;
color: #9c47fc;
display: block;
margin-top:7%;
background: -webkit-linear-gradient(#9c47fc, #356ad2);
-webkit-background-clip: text;}
.countingMap{
font-size:70px;
color:red;
margin-top:7%;
}

.row_num {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  padding: 0 4px;
}

/* Create four equal columns that sits next to each other */
.column_number {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
  max-width: 25%;
  padding: 0 4px;
}

    .column_number{
    text-align:center;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
  .column_number {
    -ms-flex: 50%;
    flex: 50%;
    max-width: 50%;
  }
}
/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column_number {
    -ms-flex:100%;
    flex:100%;
    max-width:100%;
  }
}

/*...........................................................Footer.............................*/
    
/*.............................................FOOTER...................................................*/

/* STYLES SPECIFIC TO FOOTER  */
.footer {
width: 100%;
position: relative;
height: auto;
background:#666666;
margin-top:10%;
}
.footer .collum {
width: 190px;
height: auto;
float: left;
box-sizing: border-box;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
padding: 0px 20px 20px 20px;
}
.footer .collum h1 {
margin: 0;
padding: 0;
font-family: inherit;
font-size: 14px;
line-height: 17px;
padding: 20px 0px 5px 0px;
color:white;
font-weight:800;
text-transform: uppercase;
letter-spacing:0.250em;
}
.footer .collum ul {
list-style-type: none;
margin: 0;
padding: 0;
}
.footer .collum ul li {
color: #f8f8f8;
font-size: 14px;
font-family: inherit;
padding: 5px 0px 5px 0px;
cursor: pointer;
}
    
.footer .collum ul li:hover{
color: #f8f8f8;
text-decoration:underline;
cursor: pointer;
}
.social ul li {
display: inline-block;
padding-right: 5px !important;
}
    
.clearfix {
clear: both;
}
@media only screen and (min-width: 1280px) {
.contain {
width: 1200px;
margin: 0 auto;
}
}
@media only screen and (max-width: 1139px) {
.contain .social {
width: 1000px;
display: block;
}
.social h1 {
margin: 0px;
}
}
@media only screen and (max-width: 950px) {
.footer .collum {
width: 33%;
}
.footer .collum h1 {
font-size: 14px;
}
.footer .collum ul li {
font-size: 13px;
}
}
@media only screen and (max-width: 500px) {
.footer .collum {
width: 50%;
}
.footer .collum h1 {
font-size: 14px;
}
.footer .collum li {
font-size: 13px;
}
}
@media only screen and (max-width: 340px) {
.footer .collum {
width: 100%;
  }
}
.footer_text{
color:white;
padding:20px 0px 5px 80px;
}
.footer_text_Copyright{
background-color:#747F8A;
color:white;
text-align:center;
font-size:15px;
padding:10px;
margin-bottom:-5%;
}
/*......................................................2x2 Col.............................................*/
.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  padding: 0 4px;
}

/* Create four equal columns that sits next to each other */
.column {
  -ms-flex:50%; /* IE10 */
  flex:50%;
  max-width:50%;
  padding: 0 4px;
}

.column img {
  margin-top: 8px;
  vertical-align: middle;
  width: 100%;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
  .column {
    -ms-flex: 50%;
    flex: 50%;
    max-width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    -ms-flex: 100%;
    flex: 100%;
    max-width: 100%;
  }
}
/*.................................................Button......................................................*/
.explore_btn{
display:inline-block;
padding:12px 20px;
border-radius:30px;
text-decoration:none;
font-weight:600px;
color:#fff;
width:50%;
margin-left:auto;
margin-right:auto;
background: #4776E6;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #8E54E9, #4776E6);
background:#00b20e; 
display: flex;
justify-content: center;
align-items: center;
transition:.5s;
box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
margin-top:7%;
    }
@media screen and (max-width:660px) {
.explore_btn{
width:98%;     
    }
    }
.explore_btn:hover{
color:#fff;
background: #4776E6;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right,#4776E6,#8E54E9);
background:#00b20e;  
transform:translate(0,-10px);
cursor:pointer;
  box-shadow:#cecbcb;
  color: #fff;

}
.fa-arrow-right{
margin-left:10px;      
    }


</style>

<body>

<!..............Navbar......................>
<?php include('includes/navbar.php')?>
<!..................................................Slider.....................................................................>

<div class="slideshow-container">

<div class="mySlider fade">
    
<img src="images/pexels-bidvine-1249611.jpg" style="width:100%;height:550px;display:block">               
</div>

<div class="mySlider fade">
<img src="images/pexels-karol-d-1113839.jpg" style="width:100%;height:550px;display:block">
</div>

<div class="mySlider fade">
    
<img src="images/pexels-pixabay-162564.jpg" style="width:100%;height:550px;display:block">
</div>

</div>
<br>

<div style="text-align:center">
  <span class="doted"></span> 
  <span class="doted"></span> 
  <span class="doted"></span> 
</div>
    
    
<!........................................................2x2 Columns................................................>
    
<h2 class="heading_col">Want to Become Contractor</h2>
<!-- Photo Grid -->
<div class="row"> 
 <div class="column shading_col">
<h2 class="heading_col1">You bring the skill. We'll make earning easy.</h2>
    
<img src="undraw/undraw_swipe_profiles1_i6mr.svg" style="width:65%;margin-left:auto;margin-right:auto;display:block">

<a href="Contractors.php" class="explore_btn" value="Login" name="save">Join Now<span class="fas fa-arrow-right"></span></a>
 </div>
 <div class="column">
<img src="images/hero-right.png" style="width:60%;margin-left:auto;margin-right:auto;display:block">
 </div>  

</div>
    
    
<!.......................................................Circle..................................................>
<h2 class="heading">What We Offer?</h2>

<div class="row">
<div class="col-12 outline">
<!-- Outline Grid -->
<div class="row_Outline"> 
    
<!.........col1.........> 

<div class="col_Outline"> 
<a href="House.php" style="text-decoration:none">
<div class="divOuter">
<div class="divInner">
<img src="Icons/icons8-property-100.png" style="margin-left:auto;margin-right:auto;width:30%;display:block;margin-top:20%;"> 
<p class="OutlineParagraph">Best Home Care<br>Plans</p>
</div>
</div>
</a>  
</div>
<!.........col2.........> 
<div class="col_Outline">
<a href="plots.php" style="text-decoration:none">
<div class="divOuter">
<div class="divInner">
<img src="Icons/icons8-land-sales-100.png" style="margin-left:auto;margin-right:auto;width:30%;display:block;
margin-top:25%;"> 

<p class="OutlineParagraph">100's of Skilled<br>Workers</p>
</div>
</div>
    </a>  
</div>  
<!.........col3.........> 
<div class="col_Outline"> 
<a href="Contractors.php" style="text-decoration:none">
<div class="divOuter">
<div class="divInner">

<img src="Icons/icons8-worker-beard-100.png" style="margin-left:auto;margin-right:auto;width:30%;display:block;
margin-top:25%;"> 

<p class="OutlineParagraph">100% Verified Workers</p>
</div>
</div>
</a>
 </div>
<!.........col4.........> 
    
<div class="col_Outline">  
<div class="divOuter">
<div class="divInner">
    
<img src="Icons/icons8-project-100.png" style="margin-left:auto;margin-right:auto;width:35%;display:block;
margin-top:25%;"> 

<p class="OutlineParagraph">1000+ paid Tasks</p>
</div>
</div>
</div>
    
</div>
</div>
</div>
    
<!--...................................................Number Animation..............................................-->
<h2 class="heading">General Operations</h2>

<div class="row_num"> 
  <div class="column_number">
<img src="images/icons8-location-100.png">
<div class="number">387</div> 
<h3>Locations in<span style="font-weight:bold;color:#00b20e"> Country Side</span></h3>
  </div>
  <div class="column_number">
<img src="images/icons8-instagram-check-mark-100.png">
<div class="number">1000</div>
<h3>thousand+ Verified Workers</h3>

  </div>  
  <div class="column_number">
<img src="images/icons8-star-100.png">
<div class="number">4</div>
<h3>+ Star Ratings</h3>
  </div>
  <div class="column_number">
<img src="images/icons8-drawing-compass-100.png">
<div class="number">100</div>
<h3>Thousands of Projects</h3>
  </div>
</div>
    
<!......................................................Footer.......................................................>
<?php include('includes/footer.php')?>

<!--......................................................MODAl................................................-->
<script>
// Get the modal
var modalparent = document.getElementsByClassName("modal_multi");
// Get the button that opens the modal
var modal_btn_multi = document.getElementsByClassName("myBtn_multi");
var modal_btn_multi = document.getElementsByClassName("myBtn_multi");
// Get the <span> element that closes the modal
var span_close_multi = document.getElementsByClassName("close_multi");
// When the user clicks the button, open the modal
function setDataIndex() {

for (i = 0; i < modal_btn_multi.length; i++)
{
                modal_btn_multi[i].setAttribute('data-index', i);
                modalparent[i].setAttribute('data-index', i);
                span_close_multi[i].setAttribute('data-index', i);
            }
        }



        for (i = 0; i < modal_btn_multi.length; i++)
        {
            modal_btn_multi[i].onclick = function() {
                var ElementIndex = this.getAttribute('data-index');
                modalparent[ElementIndex].style.display = "block";
            };

            // When the user clicks on <span> (x), close the modal
            span_close_multi[i].onclick = function() {
                var ElementIndex = this.getAttribute('data-index');
                modalparent[ElementIndex].style.display = "none";
            };

        }

        window.onload = function() {

            setDataIndex();
        };

        window.onclick = function(event) {
            if (event.target === modalparent[event.target.getAttribute('data-index')]) {
                modalparent[event.target.getAttribute('data-index')].style.display = "none";
            }

            // OLD CODE
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };

//XXXXXXXXXXXXXXXXXXXXXXX    Modified old code    XXXXXXXXXXXXXXXXXXXXXXXXXX

// Get the modal

        var modal = document.getElementById('myModal');

// Get the button that opens the modal
        var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
        var span = modal.getElementsByClassName("close")[0]; // Modified by dsones uk

// When the user clicks on the button, open the modal

        btn.onclick = function() {

            modal.style.display = "block";
        }

// When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }



    </script>
<!.....................Number Script.................>
    
    
<script type="text/javascript">
$(".number").counterUp({delay:10,time:1000})
</script>
    
<!...................................Automatic Slides..................................>
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlider");
  var dots = document.getElementsByClassName("doted");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" activated", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " activated";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<!...........................................SCrolling Navbar effect.............................................>
<script>
$(window).scroll(function() {
    if ($(window).scrollTop() > 10) {
        $('#myTopnav').addClass('floatingNav');
    } else {
        $('#myTopnav').removeClass('floatingNav');
    }
});

</script>
<!..............................................Sticky navbar......................................................>

<?php include('includes/scripts.php')?>
</body>
</html>