<?php session_start(); ?>
<?php include('db.php');?>
<!DOCTYPE html>
<html>
<head>

</head>
<style>
table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td,table th {
  padding:20px;
}

table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
table tr:nth-child(even){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}

.headings{
position:relative;
left:10px;
}
/*......................................................detail Cont...................................*/
.detail_container{
width:100%;
padding:10px;
}
/*.............................................Profile.......................................................*/
.profile_row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  padding: 0 4px;
border:1px solid black;
}

/* Create four equal columns that sits next to each other */
.profile_column {
  -ms-flex:50%; /* IE10 */
  flex:50%;
  max-width:50%;
  padding: 0 4px;
}

.profile_column img {
  margin-top: 8px;
  vertical-align: middle;
  width: 100%;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
  .profile_column {
    -ms-flex: 50%;
    flex: 50%;
    max-width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .profile_column {
    -ms-flex: 100%;
    flex: 100%;
    max-width: 100%;
  }
}
.buttons{
background: #4776E6;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #8E54E9, #4776E6);
background: linear-gradient(to right,#00b20e,#00b40e); 
color:#fff;
padding: 12px 20px;
border: none;
border-radius:10px;
cursor: pointer;
transition:.5s;
width:20%;
margin-bottom:3%;
}
.buttons:hover {
color:#fff;
background: #4776E6;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right,#4776E6,#8E54E9);
background: linear-gradient(to right,#00b40e,#00b20e); 
transform:translate(0,-10px);
cursor:pointer;
}
.btn{
background: linear-gradient(to right,#00b20e,#00b40e); 
  color:#fff;
  padding:13px 20px;
  border: none;
  border-radius:10px;
  cursor: pointer;
transition:.5s;
width:100%;
text-decoration:none;
}

.btn:hover {
color:#fff;
background: linear-gradient(to right,#00b20e,#00b40e); 
transform:translate(0,-10px);
cursor:pointer;
}
.btn-danger{
background-color:#b90f0f;
  color:#fff;
  padding:13px 20px;
  border: none;
  border-radius:10px;
  cursor: pointer;
transition:.5s;
width:100%;
text-decoration:none;
}
</style>

<body>
<!..............Header......................>    
<?php include('userpageheader.php')?>
<?php include('usersidebar.php')?>
    
    
<!-- Photo Grid -->
<div class="profile_row"> 
<!-- ...........................................Profile col 1................................................... -->
<div class="profile_column">
<?php
$name=$_SESSION['email'];
$sql = "select * from signup where email='$name'";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)){
while($row = mysqli_fetch_assoc($result)){
?>

<form method="POST" action="code.php">
<input type="hidden" name="update_id"  value="<?php  echo $row['id']; ?>">
<h2 class="headings">Profile Credentials</h2>
<div class="detail_container">
<div class="row">
<div class="col-half">
<div class="input-group input-group-icon">
<input type="text" placeholder="First Name" name="update_name" value="<?php echo $row['name'] ?>">
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>
</div>
    
<div class="col-half">
<div class="input-group input-group-icon">
<input type="text" placeholder="First Name" name="update_email" value="<?php echo $row['email'] ?>">
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>
</div>
    
</div> 
    
    
<div class="row">
<div class="col-half">
    
<div class="input-group input-group-icon">
<input type="text" placeholder="First Name" name="update_phone" value="<?php echo $row['phone'] ?>">
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>
</div>
    
<div class="col-half">
<div class="input-group input-group-icon">
<input type="text" name="update_password" value="<?php echo $row['password'] ?>">
<div class="input-icon"><i class="fa fa-user"></i></div>
</div> 
</div>
</div> 
     
<button type="submit" name="UserEditBtn" class="buttons">Save Changes</button>
    
</div>  
</form>    
    
    
<?php
}
}
?>
</div>
<!--..............................................Profile Col2............................................. -->
<div class="profile_column">

</div>
</div>
    
<!--.........................................Requests....................................................-->
<h2 class="headings">Contractor Request</h2>
    
<div class="row" style="padding:10px;">
<br>
<?php
$connection=mysqli_connect("localhost","root","","plumbing");
$name=$_SESSION['email'];
$query= "select * from  contractor where email='$name'";
$query_run=mysqli_query($connection,$query);
?>

<div class="panel-body">
<table class="table" id="example">
<thead>
<tr>
<th style="display:none;">ID</th>
<th scope="col">Contractor Name</th>
<th scope="col">Email</th>
<th scope="col">Phn#</th>
<th scope="col">Experienece</th>
<th scope="col">City</th>
<th scope="col">Gig Title</th>
<th scope="col">Price/Hr</th>

</tr>
</thead>
<tbody>
    
<?php
if(mysqli_num_rows($query_run)>0){
while($row=mysqli_fetch_assoc($query_run)){
?>
<tr>
<td style="display:none;"><?php echo $row['id'] ?></td>
<td><?php  echo $row['FirstName']; ?> <?php  echo $row['LastName']; ?></td>
<td><?php  echo $row['email']; ?></td>
<td><?php  echo $row['ContactNumber']; ?></td>
<td><?php  echo $row['Experienece']; ?></td>
<td><?php  echo $row['City']; ?></td>
<td><?php  echo $row['gigTitle']; ?></td>
<td><?php  echo $row['price']; ?></td>
</tr>
<?php
}
}
else{
echo"No Contractor Request";
}
?>  
      
   
</tbody>
</table>
</div>  
</div>  

    
<?php include('includes/footer.php')?>

    
</body>
<?php include('includes/scripts.php')?>
</html>