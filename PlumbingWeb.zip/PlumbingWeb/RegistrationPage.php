<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<!.........................................JQUERY CDN FOR ICON...................................................>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!--Get your own code at fontawesome.com(icons)-->   
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

</head>
<style>
*{
box-sizing:border-box;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
/*......................................Header...............................*/
.header {
  overflow: hidden;
  background-color:#00b20e;
  padding: 20px 10px;
}

.header-right {
float: right;

}
.active {
border:2px solid white;
border-radius:20px;
padding:6px 25px;
text-decoration:none;
color:white;

}
.header-left{
  float:left;
}
@media screen and (max-width: 500px) {

  .header-right {
    float:right;
  }
 .header-left {
    float:left;
  }

}

/*.......................................Topnav............................*/
.floatingNav {
  width:100%;
  box-shadow: 0px 6px 10px #999;
}

.topnav {
  overflow: hidden;
  background-color:#fff;
border-bottom:1px solid #c6bdbd;
}

.topnav a {
  float: left;
  display: block;
  color:#00b20e;
  text-align: center;
  padding:28px 30px;
  text-decoration: none;
  font-size: 17px;
font-weight:bold;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
/*........................................................Form Header........................................................*/
.Form_head{
margin-left:2%;
color:#00b20e;
}
    
/*...............................................Registration Page..........................................................*/
    

.bg-img {
  /* The image used */
  background-image: url("images/BgImageForm.jpg");

  min-height:515px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
padding-top:10px;
margin-top:5%;
}

/* Add styles to the form container */
.container_hero{
margin-top:5%;
width:45%;
margin-left:auto;
margin-right:auto;
padding:16px;
border-radius:10px;
background-color:rgba(102, 102, 102, 0.64);
}
@media screen and (max-width: 600px) {
.container_hero{
width:100%;
  }
}
    
    
    
/*.......................................................Form...............................................*/
.submit_btn{
background-color: #00b20e;
padding:10px;
width:100%;
color:white;
border:1px solid #00b20e;
border-radius:5px;
}

/*..............................................Form Login/Signup.........................*/
.Register_form{
margin-top:2%;
}
input,
input[type="radio"] + label,
input[type="checkbox"] + label:before,
select option,
select {
  width: 100%;
  padding: 1em;
  line-height: 1.4;
  background-color: #f9f9f9;
  border: 1px solid #e5e5e5;
  border-radius: 3px;
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
input:focus {
  outline: 0;
  border-color: #64ac15;
}
input:focus + .input-icon i {
  color: #7ed321;
}
input:focus + .input-icon:after {
  border-right-color: #7ed321;
}
input[type="radio"] {
  display: none;
}
input[type="radio"] + label,
select {
  display: inline-block;
  width: 50%;
  text-align: center;
  float: left;
  border-radius: 0;
}
input[type="radio"] + label:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
input[type="radio"] + label:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
input[type="radio"] + label i {
  padding-right: 0.4em;
}
input[type="radio"]:checked + label,
input:checked + label:before,
select:focus,
select:active {
  background-color: #7ed321;
  color: #fff;
  border-color: #64ac15;
}
input[type="checkbox"] {
  display: none;
}
input[type="checkbox"] + label {
  position: relative;
  display: block;
  padding-left: 1.6em;
}
input[type="checkbox"] + label:before {
  position: absolute;
  top: 0.2em;
  left: 0;
  display: block;
  width: 1em;
  height: 1em;
  padding: 0;
  content: "";
}
input[type="checkbox"] + label:after {
  position: absolute;
  top: 0.45em;
  left: 0.2em;
  font-size: 0.8em;
  color: #fff;
  opacity: 0;
  font-family: FontAwesome;
  content: "\f00c";
}
input:checked + label:after {
  opacity: 1;
}
select {
  height: 3.4em;
  line-height: 2;
}
select:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
select:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
select:focus,
select:active {
  outline: 0;
}
select option {
  background-color: #7ed321;
  color: #fff;
}
.input-group {
  margin-bottom: 1em;
  zoom: 1;
}
.input-group:before,
.input-group:after {
  content: "";
  display: table;
}
.input-group:after {
  clear: both;
}
.input-group-icon {
  position: relative;
}
.input-group-icon input {
  padding-left: 4.4em;
}
.input-group-icon .input-icon {
  position: absolute;
  top: 0;
  left: 0;
  width: 3.4em;
  height: 3.4em;
  line-height: 3.4em;
  text-align: center;
  pointer-events: none;
}
.input-group-icon .input-icon:after {
  position: absolute;
  top: 0.6em;
  bottom: 0.6em;
  left: 3.4em;
  display: block;
  border-right: 1px solid #e5e5e5;
  content: "";
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.input-group-icon .input-icon i {
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.container {
  width:70%;
  padding: 1em 3em 2em 3em;
  margin: 0em auto;
  background-color: #fff;
  border-radius: 4.2px;
  box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.2);
}
@media screen and (max-width:600px) {
.container {
  width:100%;
}
}

.row {
  zoom: 1;
}
.row:before,
.row:after {
  content: "";
  display: table;
}
.row:after {
  clear: both;
}

.SignInLink{
text-align:center;
display:block;
text-decoration:none;
color:white;
margin-top:3%;
}
.SignInLink:hover{
text-decoration:underline;
cursor:pointer;
}
.SignIn_heads{
text-align:center;
display:block;
color:white;
}



</style>

<body>
<!..............Navbar......................>
<?php include('includes/navbar.php')?>
<!..............................................SignUp Form.............................................................>


<div class="bg-img">
  <form name="myform" method="post" action="signupdata.php" class="container_hero Register_form" onsubmit="return validateemail();">
<h1 class="SignIn_heads">Register Now, It’s Free!</h1>
    
<div class="input-group input-group-icon">
<input type="text" placeholder="User Name" name="name" required>
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>

<div class="input-group input-group-icon">
<input type="email" placeholder="User Email" name="email" required>
<div class="input-icon"><i class="fa fa-envelope"></i></div>
</div>

<div class="input-group input-group-icon">
<input type="tel" placeholder="11 Digit Contact Number" name="phone" pattern="^\d{11}$" required>
<div class="input-icon"><i class="fa fa-mobile"></i></div>
</div>
    
<div class="input-group input-group-icon">
<input type="password" pattern="^\d{6}$" placeholder="Password Length not more than 6 digit" name="password" required>
<div class="input-icon"><i class="fa fa-lock"></i></div>
</div>


<div class="row">
<input type="submit" class="submit_btn" value="SignUp Now" name="user_submit">
</div> 
    
<a href="login.php" class="SignInLink">Already Have Account?<span style="font-weight:bold;color:white;">SignIn</span></a>
  </form>
</div>



<!...............................Footer...........................................................................>
<?php include('includes/footer.php')?>
<?php include('includes/scripts.php')?>
    
<script>  
function validateemail()  
{  

var x=document.myform.email.value;  
var password=document.myform.password.value;  
    
var atposition=x.indexOf("@");  
var dotposition=x.lastIndexOf(".");  
if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  }  
if(password.length<6){  
alert("Password must be at least 6 characters long.");  
return false;  
} 

}  
</script>  
</body>
</html>