<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
</head>
<style>
*{
box-sizing:border-box;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
/*......................................Header...............................*/
.header {
  overflow: hidden;
  background-color:#00b20e;
  padding: 20px 10px;
}
.logotext{font-family: "Audiowide", sans-serif;
font-size-adjust:42px;
font-weight:300;
}
.logotext{
  color:#fff;
padding:25px 18px;
  text-decoration: none;
  font-size: 17px;
font-weight:bold;    
    }
.header-right {
float: right;

}
.active {
border:2px solid white;
border-radius:20px;
padding:6px 25px;
text-decoration:none;
color:white;

}
.header-left{
  float:left;
}
@media screen and (max-width: 500px) {

  .header-right {
    float:right;
  }
 .header-left {
    float:left;
  }

}



</style>

<body>
<!..............Header......................>
<div class="header">
<div class="header-left">
<a href="#default" class="logotext">WebName</a>
</div>
<div class="header-right">
<a class="active" href="logout.php">Logout</a>  
</div>
</div>

    




<!..............................................Sticky navbar......................................................>


</body>
</html>