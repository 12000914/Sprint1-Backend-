<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
   background-color:#00b20e;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a{
padding: 8px 8px 8px 8px;
text-decoration: none;
font-size:17px;
color: #ffff;
display: block;
transition: 0.3s;
margin-top:10px;
border-radius:30px;
text-align:center;
border:1px solid white;
width:80%;
position:relative;
left:20px;
}



.sidenav a:hover {
  color: #e6e3e3;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
color:white;
cursor:pointer;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/*.....................................Modal......................................................*/
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
padding-top:20px; /* Location of the box */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgb(0,0,0); /* Fallback color */
background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
overflow-y:scroll;
        }

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding:40px;
border: 1px solid #888;
width:60%;
}
@media screen and (max-width:600px) {
.modal-content {
width:100%;
border-radius:1px;
border:1px solid white;

  }
}
/* The Close Button */
.close {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
        }

.close:hover,
.close:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}
/*............................................Modal Form.............................................*/
    
/*.......................................................Form...............................................*/
.submit_btn{
background-color: #00b20e;
padding:10px;
width:100%;
color:white;
border:1px solid #00b20e;
border-radius:5px;
}

/*..............................................Form Login/Signup.........................*/
input,
input[type="radio"] + label,
input[type="checkbox"] + label:before,
select option,
select {
  width: 100%;
  padding: 1em;
  line-height: 1.4;
  background-color: #f9f9f9;
  border: 1px solid #e5e5e5;
  border-radius: 3px;
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}

input:focus {
  outline: 0;
  border-color: #64ac15;
}
input:focus + .input-icon i {
  color: #7ed321;
}
input:focus + .input-icon:after {
  border-right-color: #7ed321;
}
input[type="radio"] {
  display: none;
}
input[type="radio"] + label,
select {
  display: inline-block;
  width: 50%;
  text-align: center;
  float: left;
  border-radius: 0;
}
input[type="radio"] + label:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
input[type="radio"] + label:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
input[type="radio"] + label i {
  padding-right: 0.4em;
}
input[type="radio"]:checked + label,
input:checked + label:before,
select:focus,
select:active {
  background-color: #7ed321;
  color: #fff;
  border-color: #64ac15;
}
input[type="checkbox"] {
  display: none;
}
input[type="checkbox"] + label {
  position: relative;
  display: block;
  padding-left: 1.6em;
}
input[type="checkbox"] + label:before {
  position: absolute;
  top: 0.2em;
  left: 0;
  display: block;
  width: 1em;
  height: 1em;
  padding: 0;
  content: "";
}
input[type="checkbox"] + label:after {
  position: absolute;
  top: 0.45em;
  left: 0.2em;
  font-size: 0.8em;
  color: #fff;
  opacity: 0;
  font-family: FontAwesome;
  content: "\f00c";
}
input:checked + label:after {
  opacity: 1;
}
select {
  height: 3.4em;
  line-height: 2;
}
select:first-of-type {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
select:last-of-type {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
select:focus,
select:active {
  outline: 0;
}
select option {
  background-color: #7ed321;
  color: #fff;
}
.input-group {
  margin-bottom: 1em;
  zoom: 1;
}
.input-group:before,
.input-group:after {
  content: "";
  display: table;
}
.input-group:after {
  clear: both;
}
.input-group-icon {
  position: relative;
}
.input-group-icon input {
  padding-left: 4.4em;
}
.input-group-icon .input-icon {
  position: absolute;
  top: 0;
  left: 0;
  width: 3.4em;
  height: 3.4em;
  line-height: 3.4em;
  text-align: center;
  pointer-events: none;
}
.input-group-icon .input-icon:after {
  position: absolute;
  top: 0.6em;
  bottom: 0.6em;
  left: 3.4em;
  display: block;
  border-right: 1px solid #e5e5e5;
  content: "";
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.input-group-icon .input-icon i {
  -webkit-transition: 0.35s ease-in-out;
  -moz-transition: 0.35s ease-in-out;
  -o-transition: 0.35s ease-in-out;
  transition: 0.35s ease-in-out;
  transition: all 0.35s ease-in-out;
}
.container {
  max-width: 38em;
  padding: 1em 3em 2em 3em;
  margin: 0em auto;
  background-color: #fff;
  border-radius: 4.2px;
  box-shadow: 0px 3px 10px -2px rgba(0, 0, 0, 0.2);
}
.row {
  zoom: 1;
}
.row:before,
.row:after {
  content: "";
  display: table;
}
.row:after {
  clear: both;
}
.col-half {
  padding-right: 10px;
  float: left;
  width: 50%;
}
.col-full{
float: left;
  width:100%;
}
.col-half:last-of-type {
  padding-right: 0;
}
.col-third {
  padding-right: 10px;
  float: left;
  width: 33.33333333%;
}
.col-third:last-of-type {
  padding-right: 0;
}
.col-forth {
  padding-right: 10px;
  float: left;
  width:25%;
}
.col-third:last-of-type {
  padding-right: 0;
}
@media only screen and (max-width: 540px) {
  .col-half {
    width: 100%;
    padding-right: 0;
  }
}
@media only screen and (max-width: 540px) {
  .col-third{
    width: 100%;
  }
}

@media only screen and (max-width:768px) {
  .col-third{
    width:100%;
  }
}
@media only screen and (max-width:1024px) {
  .col-third{
    width:100%;
  }
}
    
    
@media only screen and (max-width: 540px) {
  .col-forth{
    width: 100%;
  }
}

@media only screen and (max-width:768px) {
  .col-forth{
    width:100%;
  }
}
@media only screen and (max-width:1024px) {
  .col-forth{
    width:100%;
  }
}
    
@media only screen and (max-width: 540px) {
  .col-full{
    width: 100%;
  }
}

@media only screen and (max-width:768px) {
  .col-full{
    width:100%;
  }
}
@media only screen and (max-width:1024px) {
  .col-full{
    width:100%;
  }
}
/*................................................Profile Pic...................................................*/

.avatar-upload {
  position: relative;
  max-width: 205px;
  margin:30px auto;
}
.avatar-upload .avatar-edit {
  position: absolute;
  right: 12px;
  z-index: 1;
  top: 10px;
}
.avatar-upload .avatar-edit input {
  display: none;
}
.avatar-upload .avatar-edit input + label {
  display: inline-block;
  width: 34px;
  height: 34px;
  margin-bottom: 0;
  border-radius: 100%;
  background: #ffffff;
  border: 1px solid transparent;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
  cursor: pointer;
  font-weight: normal;
  transition: all 0.2s ease-in-out;
}
.avatar-upload .avatar-edit input + label:hover {
  background: #f1f1f1;
  border-color: #d6d6d6;
}
.avatar-upload .avatar-edit input + label:after {
  content: "\f040";
  font-family: "FontAwesome";
  color: #757575;
  position: absolute;
  top: 10px;
  left: 0;
  right: 0;
  text-align: center;
  margin: auto;
}
.avatar-upload .avatar-preview {
  width: 192px;
  height: 192px;
  position: relative;
  border-radius: 100%;
  border:7px solid #00b20e;
}
.avatar-upload .avatar-preview > div {
  width: 100%;
  height: 100%;
  border-radius: 100%;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}
.SignupLink{
margin-left:auto;
margin-right:auto;
width:40%;
text-decoration:none;
color:dimgrey;
}
.SignupLink:hover{
text-decoration:underline;
color:dimgrey;
cursor:pointer;
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
<span href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</span>
<p style="color:white;font-size:12px;text-align:center;" class="email"><?php echo $_SESSION['email']; ?></p>
<hr>
<a href="userpage.php" class="border">Dashboard</a>    
<!.....................................................Projects....................................................>
<a href="#" class="border myBtn_multi">Become Contractor</a>

<!-- The Modal No1 -->
<div class="modal modal_multi">
<!-- Modal content No1 -->
<div class="modal-content">

<!...................Modal2 Form..................................>
    
<form class="Register_form" method="post" action="Contractor_add.php" enctype="multipart/form-data">   
    
<span class="close close_multi">×</span>
<br>
<h2 class="SignIn_head">Contractor Profile</h2>

<div class="avatar-upload">
<div class="avatar-edit">
<input type='file' id="imageUpload" accept=".png, .jpg, .jpeg" name="image" required>
<label for="imageUpload"></label>
</div>
<div class="avatar-preview">
<div id="imagePreview" style="background-image:url('undraw/undraw_profile_pic_ic5t.svg')">
</div>
</div>
</div>
    
<div class="row">
<div class="col-half">
    
<div class="input-group input-group-icon">
<input type="text" placeholder="First Name" name="FirstName" required>
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>
</div>
    
<div class="col-half">
<div class="input-group input-group-icon">
<input type="text" placeholder="Last Name" name="LastName" required>
<div class="input-icon"><i class="fa fa-user"></i></div>
</div>
    
</div>
</div>
    
    
<div class="row">
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="tel" placeholder="11 Digit Contact Number" name="ContactNumber" pattern="^\d{11}$" required>
<div class="input-icon"><i class="fa fa-mobile"></i></div>
</div>
</div>
  
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="email" placeholder="Email..." name="email" value="<?php echo $_SESSION['email']; ?>" required>
<div class="input-icon"><i class="fa fa-envelope"></i></div>
</div>
</div>
</div>  
<hr>
    
<div class="row">
<div class="col-half">
<small id="demo2" style="color:red;"></small>
<div class="input-group input-group-icon">
<input placeholder="Experience(xx)" name="Experienece" pattern="^\d{2}$" required>
<div class="input-icon"><i class="fas fa-user-tie"></i></div>
</div>
</div>

<div class="col-half">
<div class="input-group">
<select name="City" required>
<option label="City">City</option>
<option value="Melbourne">Melbourne</option>
</select>
    
<select name="SupportiveLanguage" required>
<option label="Supportive language">Supportive language</option>
<option value="English">English</option>
<option value="Others">Others</option>
</select>
</div>
</div>
</div>



<div class="row">
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Gig Title" name="gigTitle" required>
<div class="input-icon"><i class="fa fa-edit"></i></div>
</div>
</div>
  
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Gig Short Description" name="gigSrtDes" required>
<div class="input-icon"><i class="fa fa-edit"></i></div>
</div>
</div>
</div>  
    
<div class="row">
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Portfolio Url" name="portfoliourl" required>
<div class="input-icon"><i class="fa fa-link"></i></div>
</div>
</div>
<div class="col-half"> 
<small id="demo3" style="color:red;"></small>
<div class="input-group input-group-icon">
<input placeholder="Price Per Hour (Digit not more than 100)" name="price" id="price" required>
<div class="input-icon"><i class="fas fa-money-check"></i></div>
</div>
</div>
</div> 
    
    
<h3>Profile Description</h3> 
<div class="row">
<div class="col-full"> 
<div class="input-group input-group-icon">
<textarea style="width:100%;height:100px;" name="ProfileDes" required></textarea>
</div>
</div>
</div>  
    
<h3>Contractor Skills</h3>
<small>Atleast 4 skill you need to become Contractor, more details must be written in Skills Description</small>
<br><br>

<div class="row">
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Skill #1 Name" name="Skill1" required>
<div class="input-icon"><i class="fa fa-cogs"></i></div>
</div>
</div>
  
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Skill #2 Name" name="Skill2" required>
<div class="input-icon"><i class="fa fa-cogs"></i></div>
</div>
</div>
</div>  
    
<div class="row">
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Skill #3 Name" name="Skill3" required>
<div class="input-icon"><i class="fa fa-cogs"></i></div>
</div>
</div>
  
<div class="col-half"> 
<div class="input-group input-group-icon">
<input type="text" placeholder="Skill #4 Name" name="Skill4" required>
<div class="input-icon"><i class="fa fa-cogs"></i></div>
</div>
</div>
</div>  

<h3>Skill's Description</h3> 
<div class="row">
<div class="col-full"> 
<div class="input-group input-group-icon">
<textarea style="width:100%;height:100px;" name="SkillDes" required></textarea>
</div>
</div>
</div>  
    

    
<div class="row">
<input type="submit" class="submit_btn" value="Submit" name="Save" onclick="StartingPriceValidation()">
</div> 
    
</form>

</div>
</div>
    
<a href="ContractorDataPageEdit.php" class="border">Contractor Data</a>
</div>
<span style="font-size:30px;cursor:pointer;margin-left:10px;" onclick="openNav()">&#9776;</span>
    

<script>

function openNav() {
  document.getElementById("mySidenav").style.width = "290px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
    
    <script>
        // Get the modal

        var modalparent = document.getElementsByClassName("modal_multi");

        // Get the button that opens the modal

        var modal_btn_multi = document.getElementsByClassName("myBtn_multi");

         var modal_btn_multi = document.getElementsByClassName("myBtn_multi");
        
        // Get the <span> element that closes the modal
        var span_close_multi = document.getElementsByClassName("close_multi");

        // When the user clicks the button, open the modal
        function setDataIndex() {

            for (i = 0; i < modal_btn_multi.length; i++)
            {
                modal_btn_multi[i].setAttribute('data-index', i);
                modalparent[i].setAttribute('data-index', i);
                span_close_multi[i].setAttribute('data-index', i);
            }
        }



        for (i = 0; i < modal_btn_multi.length; i++)
        {
            modal_btn_multi[i].onclick = function() {
                var ElementIndex = this.getAttribute('data-index');
                modalparent[ElementIndex].style.display = "block";
            };

            // When the user clicks on <span> (x), close the modal
            span_close_multi[i].onclick = function() {
                var ElementIndex = this.getAttribute('data-index');
                modalparent[ElementIndex].style.display = "none";
            };

        }

        window.onload = function() {

            setDataIndex();
        };

        window.onclick = function(event) {
            if (event.target === modalparent[event.target.getAttribute('data-index')]) {
                modalparent[event.target.getAttribute('data-index')].style.display = "none";
            }

            // OLD CODE
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };

//XXXXXXXXXXXXXXXXXXXXXXX    Modified old code    XXXXXXXXXXXXXXXXXXXXXXXXXX

// Get the modal

        var modal = document.getElementById('myModal');

// Get the button that opens the modal
        var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
        var span = modal.getElementsByClassName("close")[0]; // Modified by dsones uk

// When the user clicks on the button, open the modal

        btn.onclick = function() {

            modal.style.display = "block";
        }

// When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }



    </script>
    
    
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#imagePreview').css('background-image', 'url('+e.target.result +')');
            $('#imagePreview').hide();
            $('#imagePreview').fadeIn(650);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#imageUpload").change(function() {
    readURL(this);
});

</script>
    

    
<script>
 function PriceValidation(){
  var x, text;

  // Get the value of the input field with id="numb"
  x = document.getElementById("demand").value;

  // If x is Not a Number or less than one or greater than 10
  if (isNaN(x) || x < 1 || x > 10) {
    text = "Input not valid";
  } else {
text = "Valid Format";
  }
  document.getElementById("demo").innerHTML = text;
}
</script>
<!...................................................AGE VALIDATION................................................>      
<script>
function ExperieneceValidation(){
var x, text;
// Get the value of the input field with id="numb"
x = document.getElementById("Experienece").value;
// If x is Not a Number or less than one or greater than 10
if (isNaN(x) || x < 1 || x >40) {
text = "Experience Out of Limit";
} else {
text = "Valid Experience";
}
document.getElementById("demo2").innerHTML = text;
}
</script>
<!.....................................................AGE VAlidation End...............................................>
<script>
 function HouseValidation(){
  var x, text;

  // Get the value of the input field with id="numb"
  x = document.getElementById("demandHouse").value;

  // If x is Not a Number or less than one or greater than 10
  if (isNaN(x) || x < 1 || x > 10) {
    text = "Input not valid";
  } else {
text = "Valid Format";
  }
  document.getElementById("demo1").innerHTML = text;
}
</script>
    
<!...................................................Contractor Price Validation.....................................>
<script>
 function StartingPriceValidation(){
  var x, text;

  // Get the value of the input field with id="numb"
  x = document.getElementById("price").value;

  // If x is Not a Number or less than 100
  if (isNaN(x) || x < 1 || x>100) {
    text = "Input not valid";
  } else {
text = "Valid Price Format";
  }
  document.getElementById("demo3").innerHTML = text;
}
</script>
</body>
</html> 
